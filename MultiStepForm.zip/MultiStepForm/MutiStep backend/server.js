// server.js

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Basic Validation Function
const validateFormData = (data) => {
  const errors = {};

  // Name validation
  if (!data.name || data.name.length === 0) {
    errors.name = 'Name is required';
  }

  // Email validation
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!data.email || !emailRegex.test(data.email)) {
    errors.email = 'Invalid email format';
  }

  // Password validation
  if (!data.password || data.password.length < 6) {
    errors.password = 'Password must be at least 6 characters';
  }

  // Confirm Password validation
  if (data.password !== data.confirmPassword) {
    errors.confirmPassword = 'Passwords must match';
  }

  return errors;
};

// Route to handle form submission
app.post('/submit-form', (req, res) => {
  const { formData } = req.body;

  // Validate form data
  const errors = validateFormData(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ errors });
  }

  // Process form data (you can save it to the database here)
  return res.status(200).json({ message: 'Form submitted successfully' });
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
