import React from 'react'
import MultiStepForm from './Compoent/MultiStepForm/MultiStepForm'

const App = () => {
  return (
   <>
   <MultiStepForm>
    
   </MultiStepForm>
   </>
  )
}

export default App
