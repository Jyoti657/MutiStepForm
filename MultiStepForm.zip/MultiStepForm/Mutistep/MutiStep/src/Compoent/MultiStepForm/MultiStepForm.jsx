import React, { useState } from 'react';
import './MultiStepForm.css'; 


import axios from 'axios';

// Helper function for validation
const validateForm = (step, formData) => {
  let errors = {};

  if (step === 1) {
    if (!formData.name) errors.name = 'Name is required';
  }

  if (step === 2) {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!formData.email) errors.email = 'Email is required';
    else if (!emailRegex.test(formData.email)) errors.email = 'Invalid email format';
  }

  if (step === 3) {
    if (!formData.password) errors.password = 'Password is required';
    else if (formData.password.length < 6) errors.password = 'Password must be at least 6 characters';
    if (formData.password !== formData.confirmPassword) errors.confirmPassword = 'Passwords must match';
  }

  return errors;
};

const MultiStepForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [currentStep, setCurrentStep] = useState(1);

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle Next button
  const handleNext = () => {
    const validationErrors = validateForm(currentStep, formData);
    if (Object.keys(validationErrors).length === 0) {
      setCurrentStep(currentStep + 1);
      setErrors({});
    } else {
      setErrors(validationErrors);
    }
  };

  // Handle Previous button
  const handlePrevious = () => {
    setCurrentStep(currentStep - 1);
  };

  // Handle Form Submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate all steps before submitting
    let allErrors = {};
    for (let step = 1; step <= 3; step++) {
      const stepErrors = validateForm(step, formData);
      if (Object.keys(stepErrors).length > 0) {
        allErrors = { ...allErrors, ...stepErrors };
      }
    }

    if (Object.keys(allErrors).length > 0) {
      setErrors(allErrors);
      return;
    }

    // Send data to the server if validation passes
    try {
      const response = await axios.post('http://localhost:5000/submit-form', {
        formData
      });
      alert(response.data.message);
    } catch (error) {
      alert('Error submitting form');
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
            </label>
            {errors.name && <p style={{ color: 'red' }}>{errors.name}</p>}
          </div>
        );
      case 2:
        return (
          <div>
            <label>
              Email:
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </label>
            {errors.email && <p style={{ color: 'red' }}>{errors.email}</p>}
          </div>
        );
      case 3:
        return (
          <div>
            <label>
              Password:
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </label>
            {errors.password && <p style={{ color: 'red' }}>{errors.password}</p>}
            <br />
            <label>
              Confirm Password:
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
              />
            </label>
            {errors.confirmPassword && <p style={{ color: 'red' }}>{errors.confirmPassword}</p>}
          </div>
        );
      default:
        return <div>Form Completed!</div>;
    }
  };

  return (
    <div>
      <h1>Multi-Step Form</h1>
      <form onSubmit={handleSubmit}>
        {renderStepContent()}
        <div>
          {currentStep > 1 && (
            <button type="button" onClick={handlePrevious}>Previous</button>
          )}
          {currentStep < 3 ? (
            <button type="button" onClick={handleNext}>Next</button>
          ) : (
            <button type="submit">Submit</button>
          )}
        </div>
      </form>
    </div>
  );
};

export default MultiStepForm;
